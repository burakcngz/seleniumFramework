**Browser configürasyonları :** configuration/configsettingsproperties  
**Report configürasyonları :** configuration/report  
**Test sonunda rapor cıktısı :** reports  
**Page Objects :** src/main/java/pageObjects  
**Tests :** src/test/java/uitests  
**Common functions :** src/test/java/common  