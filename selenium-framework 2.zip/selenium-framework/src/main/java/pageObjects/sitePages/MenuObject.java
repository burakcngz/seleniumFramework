package pageObjects.sitePages;

import org.openqa.selenium.WebDriver;
import pageObjects.BasePage;

public class MenuObject extends BasePage {
	public MenuObject(WebDriver driver) {
		super(driver);
	}
}
