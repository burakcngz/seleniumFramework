package pageObjects.sitePages.moduleOne;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedConditions;
import pageObjects.BasePage;

public class ExamplePage extends BasePage {
	public ExamplePage(WebDriver driver) {
		super(driver);
	}
	@FindBy(id="demo")
	WebElement element;
	public void test1() {
		wait.until(ExpectedConditions.presenceOfElementLocated(By.id("bak")));
	}
	// Example usage of actions and Js methods.
	public void testJSandActionUsage() {
		jsUtils.clickElement(element);
		actionUtils.clickElement(element);
	}
}
