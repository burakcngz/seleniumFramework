package config;

public class TestConfig {
	public static final String excelPath = "src\\test\\java\\utils\\testdata.xlsx";
	public static final String configpath = "src\\configuration\\configsetting.properties";
	public static final String reportConfigPath = "src\\configuration\\report.properties";
	public static final String BROWSER = "chrome";
}
